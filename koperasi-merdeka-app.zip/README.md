# APK Koperasi Merdeka

Pembungkus Android untuk **Web-Apps Koperasi Simpan Pinjam** — aplikasi tetap PHP + database di server, APK ini cuma "jendela" native yang membuka situs koperasi langsung, jadi tampil seperti aplikasi asli (ikon sendiri, layar penuh, tanpa address bar browser).

Tidak perlu Android Studio maupun laptop — semuanya dibangun otomatis lewat GitHub Actions, bisa dari iPad.

## Yang Perlu Disiapkan Dulu

Buka `app.config.json`, pastikan `appUrl` sudah alamat situs koperasi yang **sudah live** (bukan localhost), contoh:

```json
{
  "appUrl": "https://satuproyeksi.com/profiles/koperasi-merdeka/",
  "appName": "Koperasi Merdeka",
  "packageId": "com.satuproyeksi.koperasimerdeka"
}
```

Kalau alamatnya beda, edit dulu sebelum upload — atau isi lewat kolom `app_url` saat menjalankan workflow nanti (tidak perlu edit file).

## Cara Membangun APK (dari iPad, lewat Safari)

1. Buka **github.com**, buat repo baru (pilih **Private**), beri nama misal `koperasi-apk`.
2. Ketuk **aA** di address bar Safari → **Request Desktop Website** (supaya tombol upload muncul).
3. **Add file → Upload files** → pilih file zip ini (jangan diekstrak dulu) → **Commit changes**.
   - Kalau di-upload sebagai zip, GitHub akan menampilkannya sebagai satu file — ekstrak dulu isinya ke folder repo lewat **Add file → Upload files** lagi dengan memilih semua file di dalamnya, atau gunakan opsi "unzip" bila tersedia di app Files sebelum upload.
4. Pastikan struktur di repo persis seperti ini di folder utama:
   ```
   app.config.json
   capacitor.config.json
   package.json
   scripts/setup.js
   www/index.html
   assets/...
   .github/workflows/build-apk.yml
   ```
5. Buka tab **Actions** → pilih **Build APK Koperasi Merdeka** → **Run workflow**.
   - Kolom `app_url` boleh dikosongkan (pakai default dari `app.config.json`), atau isi manual.
   - Klik **Run workflow** hijau.
6. Tunggu 6–10 menit sampai muncul centang hijau. Ketuk run-nya, scroll ke **Artifacts**, unduh **KoperasiMerdeka-APK** (berupa zip).
7. Buka **Files** di iPad, ekstrak zip itu sampai muncul `app-debug.apk`.
8. Kirim APK ke HP/tablet Android (WhatsApp, Google Drive, atau kabel data), buka file-nya, izinkan **"Instal dari sumber tidak dikenal"** kalau diminta. Kalau Play Protect memperingatkan, pilih **Tetap instal** — wajar untuk APK di luar Play Store.

## Update Versi Berikutnya

- **Kalau cuma situs/PHP yang berubah** → tidak perlu build ulang APK sama sekali. APK memuat situs langsung, jadi cukup upload perubahan ke hosting seperti biasa.
- **Perlu build ulang hanya kalau** mengganti: alamat situs, nama aplikasi, ikon, atau `packageId`.
- Kalau build ulang, naikkan `version_code` (2, 3, dst) saat menjalankan workflow, lalu instal APK baru menimpa yang lama (data login tetap, tidak perlu uninstall dulu).

## APK Rilis Bertanda Tangan (opsional, untuk Play Store)

APK debug (bawaan) sudah cukup untuk dipasang sendiri atau dibagikan ke anggota koperasi. Untuk publikasi di Play Store, dibutuhkan keystore sendiri lalu isi lewat **Settings → Secrets and variables → Actions** di repo:

- `KEYSTORE_BASE64` — isi file `.jks` yang sudah di-encode base64
- `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`

Lalu jalankan workflow dengan opsi `release` dicentang. **Simpan keystore-nya baik-baik** — kalau hilang, aplikasi tidak bisa diperbarui lagi di Play Store.

## Catatan Jujur

- APK ini adalah **WebView shell** (bukan aplikasi native penuh) — semua logika & data tetap di server PHP/SQLite, sama seperti versi web. Cocok untuk memberi anggota/admin pengalaman "kayak aplikasi", bukan untuk kebutuhan offline penuh.
- Kalau HP tidak ada koneksi internet, aplikasi akan menampilkan halaman error bawaan Android WebView (belum ada halaman "tidak ada koneksi" custom seperti di aplikasi POS — bisa ditambahkan kalau dibutuhkan).
- Tidak ada fitur native tambahan di sini (tidak seperti APK POS yang punya printer Bluetooth) — Koperasi Merdeka tidak butuh itu. Kalau nanti perlu native lain (misal notifikasi push, scan QR pakai kamera), bisa ditambahkan sebagai plugin Capacitor terpisah.
