// Menyiapkan proyek Android secara otomatis: alamat aplikasi, nama, ikon, splash.
// Dijalankan oleh GitHub Actions (atau manual: npm run setup) sebelum build APK.

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const run = (cmd, opts = {}) => {
  console.log('$ ' + cmd);
  execSync(cmd, { stdio: 'inherit', cwd: ROOT, ...opts });
};

// 1) Baca app.config.json, boleh ditimpa oleh environment variable (dipakai workflow GitHub Actions)
const cfgPath = path.join(ROOT, 'app.config.json');
const appCfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
const APP_URL = process.env.APP_URL || appCfg.appUrl;
const APP_NAME = process.env.APP_NAME || appCfg.appName;
const PACKAGE_ID = process.env.PACKAGE_ID || appCfg.packageId;

console.log(`Konfigurasi: ${APP_NAME} (${PACKAGE_ID}) -> ${APP_URL}`);

// 2) Tulis ulang capacitor.config.json dengan nilai final
const capCfgPath = path.join(ROOT, 'capacitor.config.json');
const capCfg = JSON.parse(fs.readFileSync(capCfgPath, 'utf8'));
capCfg.appId = PACKAGE_ID;
capCfg.appName = APP_NAME;
capCfg.server.url = APP_URL;
fs.writeFileSync(capCfgPath, JSON.stringify(capCfg, null, 2));

// 3) Tambahkan platform Android kalau belum ada, atau sinkronkan kalau sudah ada
const androidDir = path.join(ROOT, 'android');
if (!fs.existsSync(androidDir)) {
  run('npx cap add android');
} else {
  run('npx cap sync android');
}

// 4) Salin ikon & splash ke folder resource Android
const resSrc = path.join(ROOT, 'assets', 'android-res');
const resDst = path.join(androidDir, 'app', 'src', 'main', 'res');

function copyRecursive(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dst, entry.name);
    if (entry.isDirectory()) copyRecursive(s, d);
    else fs.copyFileSync(s, d);
  }
}
copyRecursive(resSrc, resDst);
console.log('Ikon & splash disalin ke android/app/src/main/res');

// 5) Pastikan mipmap-anydpi-v26 mengarah ke foreground adaptif + background krem
const anydpiDir = path.join(resDst, 'mipmap-anydpi-v26');
fs.mkdirSync(anydpiDir, { recursive: true });
const adaptiveXml = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
`;
fs.writeFileSync(path.join(anydpiDir, 'ic_launcher.xml'), adaptiveXml);
fs.writeFileSync(path.join(anydpiDir, 'ic_launcher_round.xml'), adaptiveXml);

const valuesDir = path.join(resDst, 'values');
fs.mkdirSync(valuesDir, { recursive: true });
const colorsPath = path.join(valuesDir, 'ic_launcher_background.xml');
fs.writeFileSync(colorsPath, `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#FAF6EE</color>
</resources>
`);

// 6) Update nama aplikasi yang tampil di bawah ikon (strings.xml)
const stringsPath = path.join(resDst, 'values', 'strings.xml');
if (fs.existsSync(stringsPath)) {
  let xml = fs.readFileSync(stringsPath, 'utf8');
  xml = xml.replace(/<string name="app_name">.*?<\/string>/, `<string name="app_name">${APP_NAME}</string>`);
  xml = xml.replace(/<string name="title_activity_main">.*?<\/string>/, `<string name="title_activity_main">${APP_NAME}</string>`);
  fs.writeFileSync(stringsPath, xml);
}

// 7) Pastikan izin INTERNET ada di AndroidManifest.xml (default Capacitor sudah menyertakan, jaga-jaga saja)
const manifestPath = path.join(androidDir, 'app', 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  if (!manifest.includes('android.permission.INTERNET')) {
    manifest = manifest.replace(
      '<application',
      '<uses-permission android:name="android.permission.INTERNET" />\n    <application'
    );
    fs.writeFileSync(manifestPath, manifest);
  }
}

console.log('Setup selesai. Siap dibangun (gradlew assembleDebug).');
